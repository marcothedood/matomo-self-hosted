# How to contribute

Great to have you here! 

## How to submit a bug report or suggest a feature?

Please read the recommendations on writing a good [bug report](https://developer.piwik.org/guides/core-team-workflow#submitting-a-bug-report) or [feature request](https://developer.piwik.org/guides/core-team-workflow#submitting-a-feature-request).

