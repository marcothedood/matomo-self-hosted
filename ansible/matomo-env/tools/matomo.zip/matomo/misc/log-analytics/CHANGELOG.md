# Changelog

## Version 4.0.0

- Process file globs in a sorted order (#291)
- Use new performance metric for server generation time (#260)
- Support for AWS Application and Elastic Load Balancer log formats (#280)
- Always disable queued tracking when sending requests from log import (#274)
- added support for Python 3.5 and above (#267)
- dropped support for Python 2.x (#267)
