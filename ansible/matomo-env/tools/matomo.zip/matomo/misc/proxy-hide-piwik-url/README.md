# Piwik Proxy Hide URL

The proxy script has been moved to [piwik/tracker-proxy](https://github.com/piwik/tracker-proxy).
